## Screenshot

![Screenshot](http://dl.dropbox.com/u/1658623/tmuxrc.png)

## Installation

``` bash
$ curl -Lo- https://raw.github.com/yesmeck/tmuxrc/master/bootstrap.sh | bash
```


[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/yesmeck/tmuxrc/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

